package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MoistureTest extends AppCompatActivity {
    Button btn1,btn2, btn3;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), SBCTest.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moisture_test);
        btn1=findViewById(R.id.button2);
        btn2=findViewById(R.id.button3);
        btn3=findViewById(R.id.button4);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sbcresult=getIntent().getStringExtra("sbcresult");
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                Intent intent=new Intent(getApplicationContext(), moistureTest_Main.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                intent.putExtra("sbcresult",sbcresult);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SBCTest.class));
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),first_vastu.class));
            }
        });
        VideoView moistureTest=findViewById(R.id.sbctest);
        String videoPath="android.resource://"+getPackageName()+"/"+R.raw.moisture_test;
        Uri uri=Uri.parse(videoPath);
        moistureTest.setVideoURI(uri);

        MediaController mediaController=new MediaController(this);
        moistureTest.setMediaController(mediaController);
        mediaController.setAnchorView(moistureTest);
    }
}