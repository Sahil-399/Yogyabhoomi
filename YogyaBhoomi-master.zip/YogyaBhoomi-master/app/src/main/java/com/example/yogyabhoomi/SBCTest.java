package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class SBCTest extends AppCompatActivity {
Button btn1,btn2, btn3;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), LocationTest.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sbctest);

        btn1=findViewById(R.id.button2);
        btn2=findViewById(R.id.button3);
        btn3=findViewById(R.id.button4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                Intent intent=new Intent(getApplicationContext(), sbc_main.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),LocationTest.class));
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),MoistureTest.class));
            }
        });
        VideoView sbctest=findViewById(R.id.sbctest);
        String videoPath="android.resource://"+getPackageName()+"/"+R.raw.sbctest;
        Uri uri=Uri.parse(videoPath);
        sbctest.setVideoURI(uri);

        MediaController mediaController=new MediaController(this);
        sbctest.setMediaController(mediaController);
        mediaController.setAnchorView(sbctest);

    }
}