package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class choicetest2 extends AppCompatActivity {
    RadioGroup radioGroup1, radioGroup2, radioGroup3, radioGroup4, radioGroup5;
    RadioButton radioButton1, radioButton2, radioButton3, radioButton4, radioButton5;
    Button b1, b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choicetest2);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        radioGroup1 = findViewById(R.id.radioGroup);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        radioGroup4 = findViewById(R.id.radioGroup4);
        radioGroup5 = findViewById(R.id.radioGroup5);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), choicetest.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId1 = radioGroup1.getCheckedRadioButtonId();
                int radioId2 = radioGroup2.getCheckedRadioButtonId();
                int radioId3 = radioGroup3.getCheckedRadioButtonId();
                int radioId4 = radioGroup4.getCheckedRadioButtonId();
                int radioId5 = radioGroup5.getCheckedRadioButtonId();
                radioButton1 = findViewById(radioId1);
                radioButton2 = findViewById(radioId2);
                radioButton3 = findViewById(radioId3);
                radioButton4 = findViewById(radioId4);
                radioButton5 = findViewById(radioId5);
                String ct6 = radioButton1.getText().toString();
                String ct7 = radioButton2.getText().toString();
                String ct8 = radioButton3.getText().toString();
                String ct9 = radioButton4.getText().toString();
                String ct10 = radioButton5.getText().toString();

                if (!ct6.isEmpty() && !ct7.isEmpty() && !ct8.isEmpty() && !ct9.isEmpty() && !ct10.isEmpty()) {
                    String ct1 = getIntent().getStringExtra("ct1");
                    String ct2 = getIntent().getStringExtra("ct2");
                    String ct3 = getIntent().getStringExtra("ct3");
                    String ct4 = getIntent().getStringExtra("ct4");
                    String ct5 = getIntent().getStringExtra("ct5");
                    Intent intent=new Intent(getApplicationContext(),choicetest3.class);
                    intent.putExtra("ct1",ct1);
                    intent.putExtra("ct2",ct2);
                    intent.putExtra("ct3",ct3);
                    intent.putExtra("ct4",ct4);
                    intent.putExtra("ct5",ct5);
                    intent.putExtra("ct6",ct6);
                    intent.putExtra("ct7",ct7);
                    intent.putExtra("ct8",ct8);
                    intent.putExtra("ct9",ct9);
                    intent.putExtra("ct10",ct10);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(choicetest2.this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }
}