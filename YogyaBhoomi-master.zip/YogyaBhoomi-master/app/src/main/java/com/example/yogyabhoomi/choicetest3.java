package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class choicetest3 extends AppCompatActivity {
    RadioGroup radioGroup1, radioGroup2, radioGroup3, radioGroup4, radioGroup5, radioGroup6;
    RadioButton radioButton1, radioButton2, radioButton3, radioButton4, radioButton5, radioButton6;
    Button b1, b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choicetest3);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        radioGroup1 = findViewById(R.id.radioGroup);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        radioGroup4 = findViewById(R.id.radioGroup4);
        radioGroup5 = findViewById(R.id.radioGroup5);
        radioGroup6 = findViewById(R.id.radioGroup6);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), choicetest2.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId1 = radioGroup1.getCheckedRadioButtonId();
                int radioId2 = radioGroup2.getCheckedRadioButtonId();
                int radioId3 = radioGroup3.getCheckedRadioButtonId();
                int radioId4 = radioGroup4.getCheckedRadioButtonId();
                int radioId5 = radioGroup5.getCheckedRadioButtonId();
                int radioId6 = radioGroup6.getCheckedRadioButtonId();
                radioButton1 = findViewById(radioId1);
                radioButton2 = findViewById(radioId2);
                radioButton3 = findViewById(radioId3);
                radioButton4 = findViewById(radioId4);
                radioButton5 = findViewById(radioId5);
                radioButton6 = findViewById(radioId6);
                String ct11 = radioButton1.getText().toString();
                String ct12 = radioButton2.getText().toString();
                String ct13 = radioButton3.getText().toString();
                String ct14 = radioButton4.getText().toString();
                String ct15 = radioButton5.getText().toString();
                String ct16 = radioButton6.getText().toString();
                if (!ct11.isEmpty() && !ct12.isEmpty() && !ct13.isEmpty() && !ct14.isEmpty() && !ct15.isEmpty()) {
                    String ct1 = getIntent().getStringExtra("ct1");
                    String ct2 = getIntent().getStringExtra("ct2");
                    String ct3 = getIntent().getStringExtra("ct3");
                    String ct4 = getIntent().getStringExtra("ct4");
                    String ct5 = getIntent().getStringExtra("ct5");
                    String ct6 = getIntent().getStringExtra("ct6");
                    String ct7 = getIntent().getStringExtra("ct7");
                    String ct8 = getIntent().getStringExtra("ct8");
                    String ct9 = getIntent().getStringExtra("ct9");
                    String ct10= getIntent().getStringExtra("ct10");
                    Intent intent=new Intent(getApplicationContext(),choice_result.class);
                    intent.putExtra("ct1",ct1);
                    intent.putExtra("ct2",ct2);
                    intent.putExtra("ct3",ct3);
                    intent.putExtra("ct4",ct4);
                    intent.putExtra("ct5",ct5);
                    intent.putExtra("ct6",ct6);
                    intent.putExtra("ct7",ct7);
                    intent.putExtra("ct8",ct8);
                    intent.putExtra("ct9",ct9);
                    intent.putExtra("ct10",ct10);
                    intent.putExtra("ct11",ct11);
                    intent.putExtra("ct12",ct12);
                    intent.putExtra("ct13",ct13);
                    intent.putExtra("ct14",ct14);
                    intent.putExtra("ct15",ct15);
                    intent.putExtra("ct16",ct16);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(choicetest3.this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }
}