package com.example.yogyabhoomi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class profile extends AppCompatActivity {
    TextView changePassword, pemail, pname, pmobile;
    Button homebtn;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), MainActivity2.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        changePassword = findViewById(R.id.change);
        homebtn = findViewById(R.id.btn);
        pname = findViewById(R.id.nm);
        pmobile = findViewById(R.id.mb);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        pemail = findViewById(R.id.pemail);
        String local_pname = getIntent().getStringExtra("name");
        String local_pmobile = getIntent().getStringExtra("mobile");
        pmobile.setText(local_pmobile);
        pname.setText(local_pname);


        if (user == null) {
            startActivity(new Intent(getApplicationContext(), LoginPage.class));
            finish();
        } else {
            reference = FirebaseDatabase.getInstance().getReference();
            pemail.setText(user.getEmail());
            String email = user.getEmail().toString();
            Query query = reference.child("Users").orderByChild("email").equalTo(email);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Iterate over the results and retrieve the user data
                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            Users user = userSnapshot.getValue(Users.class);
                            if (user != null) {
                                // Use the retrieved user data
                                String name = user.name;
                                String mobileNumber = user.mobile;
                                pname.setText(name);
                                pmobile.setText(mobileNumber);
                            }
                        }
                    } else {
                        // Handle case where no user was found with the given email ID
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }
        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity2.class));
            }
        });
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                auth.sendPasswordResetEmail(user.getEmail()).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(profile.this, "Email Sent", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(profile.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

    }
}