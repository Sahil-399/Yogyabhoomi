package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class sbc_main extends AppCompatActivity {
EditText depth,impr,l,b,w;
Button b1,b2,calculate;
RadioGroup radioGroup;
RadioButton radioButton;
public int testFlag=0;
    double sbc=0;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), SBCTest.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sbc_main);
        depth=findViewById(R.id.depth);
        impr=findViewById(R.id.impr);
        l=findViewById(R.id.length);
        b=findViewById(R.id.breadth);
        w=findViewById(R.id.width);
        b1=findViewById(R.id.button3);
        b2=findViewById(R.id.button2);
        calculate=findViewById(R.id.calculate);
        radioGroup=findViewById(R.id.radioGroup);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SBCTest.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(testFlag==1) {
                    String sbcresult=String.valueOf(sbc);
                    String riskfactor=getIntent().getStringExtra("riskfactor");
                    String lifesutability=getIntent().getStringExtra("lifesutability");
                    Intent intent=new Intent(getApplicationContext(), MoistureTest.class);
                    intent.putExtra("riskfactor",riskfactor);
                    intent.putExtra("lifesutability",lifesutability);
                    intent.putExtra("sbcresult",sbcresult);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(sbc_main.this, "Empty Field!!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(radioId);
                String nm=radioButton.getText().toString().trim();
                int density=00;
                if(nm.equals("RCC"))
                {
                    density=2500;
                } else if (nm.equals("PCC")) {
                    density=2400;
                }
                else{
                    density=2400;
                }
                if(l==null && b==null && w==null && depth==null && impr==null && nm==null)
                {
                    Toast.makeText(sbc_main.this, "Empty Fields!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    double len=Double.parseDouble(l.getText().toString());
                    double bred=Double.parseDouble(b.getText().toString());
                    double wid=Double.parseDouble(w.getText().toString());
                    double imp=Double.parseDouble(impr.getText().toString());
                    double dep=Double.parseDouble(depth.getText().toString());
                    double soilResistance=(len*bred*wid*density*dep)/imp;
                    sbc=soilResistance/((len*bred)*2);
                    testFlag=1;
                    String riskfactor=getIntent().getStringExtra("riskfactor");
                    String lifesutability=getIntent().getStringExtra("lifesutability");
                    Toast.makeText(sbc_main.this, "SBC Result "+sbc, Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}