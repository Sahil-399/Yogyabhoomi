package com.example.yogyabhoomi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity3 extends AppCompatActivity {
    Button b1,b2;
    FirebaseUser user;
    FirebaseAuth auth;
    DatabaseReference reference, reference1;
    FirebaseDatabase db;
    TextView tv1,tv2;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), first_vastu.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tv1=findViewById(R.id.mobile1);
        tv2=findViewById(R.id.name1);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference();
        String email = user.getEmail().toString();
        Query query = reference.child("Users").orderByChild("email").equalTo(email);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Iterate over the results and retrieve the user data
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        Users user = userSnapshot.getValue(Users.class);
                        if (user != null) {
                            // Use the retrieved user data
                            String name = user.name;
                            String mobile = user.mobile;
                            tv1.setText(mobile);
                            tv2.setText(name);
                        }
                    }
                } else {
                    // Handle case where no user was found with the given email ID
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        String suburb_local = getIntent().getStringExtra("suburb");
        String sbcresult = getIntent().getStringExtra("sbcresult");
        String riskfactor = getIntent().getStringExtra("riskfactor");
        String lifesutability = getIntent().getStringExtra("lifesutability");
        String moisturevalue = getIntent().getStringExtra("moisturevalue");
        String moisturepercentage = getIntent().getStringExtra("moisturepercentage");
        String future = getIntent().getStringExtra("future");
        b1=findViewById(R.id.btn);
        b1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                String name=tv2.getText().toString();
                String mobile=tv1.getText().toString();
                createInvoicePdf(name,mobile,email,riskfactor,lifesutability,sbcresult,moisturevalue,moisturepercentage,suburb_local,future);
                User1 user1=new User1(name, mobile, email,riskfactor,lifesutability,sbcresult,moisturepercentage,suburb_local);
                db=FirebaseDatabase.getInstance();
                reference1=db.getReference("Customer");
                reference1.child(name).setValue(user1);
            }
        });
        b2=findViewById(R.id.btn2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),MainActivity2.class));
            }
        });

    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createInvoicePdf(String name, String mobile, String email, String riskfactor,String lifesutability,
                                  String sbcresult, String moisturevalue, String moisturepercentage, String suburb, String future) {
        // Create a new document
        Document document = new Document();
        Bitmap logoBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.new_logo);
        byte[] logoByteArray = bitmapToByteArray(logoBitmap);

        try {
            // Create a file in the Documents directory
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), name + "_YogyaBhoomi1.pdf");
            file.createNewFile();
            // Create a PdfWriter instance to write to the file
            OutputStream outputStream = new FileOutputStream(file);
            PdfWriter.getInstance(document, outputStream);

            // Open the document
            document.open();


            Image logoImage = Image.getInstance(logoByteArray);
            logoImage.scaleAbsolute(200,200);
            logoImage.setAlignment(Element.ALIGN_CENTER);
            document.add(logoImage);


            Font hotelNameFont = new Font(Font.FontFamily.TIMES_ROMAN, 40, Font.BOLD);
            Font hotelNameFont1 = new Font(Font.FontFamily.TIMES_ROMAN, 24, Font.BOLD);
            Font hotelNameFont2 = new Font(Font.FontFamily.TIMES_ROMAN,18 , Font.BOLD);
            Font myFont3 = new Font(Font.FontFamily.TIMES_ROMAN,16 , Font.BOLD);
            Font myFont4 = new Font(Font.FontFamily.TIMES_ROMAN,16);
            // Add hotel name and invoice title to the document
            Paragraph hotelNameParagraph = new Paragraph("YogyaBhoomi",hotelNameFont);
            hotelNameParagraph.setAlignment(Element.ALIGN_CENTER);
            document.add(hotelNameParagraph);
            Paragraph invoiceTitleParagraph = new Paragraph("YogyaBhoomi Analysed Report",hotelNameFont1);
            invoiceTitleParagraph.setAlignment(Element.ALIGN_CENTER);
            document.add(invoiceTitleParagraph);
            
            // Add customer name and check-in/out dates to the document
            Paragraph customerNameParagraph = new Paragraph("User Name: " + name,hotelNameFont2);
            document.add(customerNameParagraph);
            Paragraph checkInDateParagraph = new Paragraph("User Mobile Number: " + mobile,hotelNameFont2);
            document.add(checkInDateParagraph);
            Paragraph checkOutDateParagraph = new Paragraph("User Email Id: " + email,hotelNameFont2);
            document.add(checkOutDateParagraph);
            Paragraph suburbParagraph = new Paragraph("User Suburb: " + suburb,hotelNameFont2);
            document.add(suburbParagraph);

            // Add a table to the document for room details
            PdfPTable table = new PdfPTable(2);
            PdfPCell cell1 = new PdfPCell(new Paragraph("Risk Factor",myFont3));
            PdfPCell cell2 = new PdfPCell(new Paragraph(riskfactor,myFont4));
            PdfPCell cell3 = new PdfPCell(new Paragraph("Life Suitability Percentage",myFont3));
            PdfPCell cell4 = new PdfPCell(new Paragraph(lifesutability,myFont4));
            PdfPCell cell5 = new PdfPCell(new Paragraph("SBC Test Result",myFont3));
            PdfPCell cell6 = new PdfPCell(new Paragraph(sbcresult,myFont4));
            PdfPCell cell7 = new PdfPCell(new Paragraph("Moisture Percentage",myFont3));
            PdfPCell cell8 = new PdfPCell(new Paragraph(moisturepercentage,myFont4));
            table.addCell(cell1);
            table.addCell(cell2);
            table.addCell(cell3);
            table.addCell(cell4);
            table.addCell(cell5);
            table.addCell(cell6);
            table.addCell(cell7);
            table.addCell(cell8);
            document.add(table);

            Paragraph tipsParagraph = new Paragraph("YogyaBhoomi Analysis for your property",myFont3);
            tipsParagraph.setAlignment(Element.ALIGN_LEFT);
            document.add(tipsParagraph);
            int moisture=Integer.parseInt(moisturepercentage);
            if(moisture>75)
            {
                Paragraph moisture_suggestion = new Paragraph("Soil is too wet. If its not rainy season, It is not advisable to construct here without the perfect guidance to undo the more moisture in soil ",myFont4);
                moisture_suggestion.setAlignment(Element.ALIGN_LEFT);
                document.add(moisture_suggestion);

            } else if (moisture>60 && moisture<75) {
                Paragraph moisture_suggestion = new Paragraph("Soil is on the border to be called as wet. If its not winter season, It is not advisable to construct here without the perfect guidance to undo the more moisture in soil",myFont4);
                moisture_suggestion.setAlignment(Element.ALIGN_LEFT);
                document.add(moisture_suggestion);
            } else if (moisture>0 && moisture<10) {
                Paragraph moisture_suggestion = new Paragraph("Soil is on very dry. If its not summer, it will be difficult to construct buildings on this land",myFont4);
                moisture_suggestion.setAlignment(Element.ALIGN_LEFT);
                document.add(moisture_suggestion);
            }
            else {
                Paragraph moisture_suggestion = new Paragraph("Soil is absolutely perfect. It is ideal for construction",myFont4);
                moisture_suggestion.setAlignment(Element.ALIGN_LEFT);
                document.add(moisture_suggestion);
            }
            Paragraph future_prediction = new Paragraph("Your Suburbs development in upcoming 5-10 years:"+future,myFont4);
            future_prediction.setAlignment(Element.ALIGN_LEFT);
            document.add(future_prediction);

            // Add a final message to the document
            Paragraph finalMessageParagraph = new Paragraph("Thank you for choosing YogyaBhoomi!",myFont3);
            finalMessageParagraph.setAlignment(Element.ALIGN_CENTER);
            document.add(finalMessageParagraph);

            // Close the document
            document.close();

            // Show a success message
            Toast.makeText(this, "PDF file saved to " + file.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // Show an error message if something goes wrong
            Toast.makeText(this, "Error generating invoice PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private byte[] bitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

}
