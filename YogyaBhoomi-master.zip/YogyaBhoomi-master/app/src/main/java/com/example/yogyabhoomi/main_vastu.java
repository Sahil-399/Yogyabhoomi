package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class main_vastu extends AppCompatActivity {
    Button b1,b2;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), first_vastu.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_vastu);
        b1=findViewById(R.id.btn);
        b2=findViewById(R.id.btn1);
        Spinner fruitsSpinner = findViewById(R.id.fruits_spinner);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),first_vastu.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String suburb_local=getIntent().getStringExtra("suburb");
                String sbcresult=getIntent().getStringExtra("sbcresult");
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                String moisturevalue=getIntent().getStringExtra("moisturevalue");
                String moisturepercentage=getIntent().getStringExtra("moisturepercentage");
                String future=getIntent().getStringExtra("future");
                Intent intent=new Intent(getApplicationContext(),MainActivity3.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                intent.putExtra("sbcresult",sbcresult);
                intent.putExtra("moisturevalue",moisturevalue);
                intent.putExtra("moisturepercentage",moisturepercentage);
                intent.putExtra("suburb",suburb_local);
                intent.putExtra("future",future);
                startActivity(intent);;
            }
        });
        fruitsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedFruit = adapterView.getItemAtPosition(i).toString();
                // TODO: Display information for the selected fruit
                TextView fruitInfoTextView = findViewById(R.id.fruit_info_text_view);
                switch (selectedFruit) {
                    case "Main Door":
                        fruitInfoTextView.setText("Main Door is the most significant place in the entire house. Main door's direction depends on each persons horoscope. But generally it is advised to build the main door at North/North East/East. Avoid buying houses with main door at South/South West");
                        break;
                    case "Study Room":
                        fruitInfoTextView.setText("Study room should face east or west direction of the house. Second best is North. Study Table should be motivate the students like trophies, rewards and certificates. Avoid the student facing an empty wall. You can also have an indoor plant in the room. ");
                        break;
                    case "Kitchen":
                        fruitInfoTextView.setText("According to Vastu Shastra, the Lord of Fire—Agni—prevails in the southeast direction of the home, which means that the ideal placement of the kitchen is the southeast direction of your home. Second best is south-west. Avoid water taps beside the stove.");
                        break;
                    case "Locker":
                        fruitInfoTextView.setText("The ideal locker direction as per Vastu should be such that it has its back to the southern wall and its door opens towards the north. Second best is east. Avoid locker is southeast, southwest, northeast. The locker should be 1 inch away from the wall");
                        break;
                    case "Toilets":
                        fruitInfoTextView.setText("Toilets should never be in North or East direction. Preferably toilets should be ideally slight above the ground. Avoid having common walls of Toilets with Kitchen, Study or Pooja room");
                        break;
                    case "Bedroom":
                        fruitInfoTextView.setText("Bedrooms are place which should be calm and peaceful. Avoid using dark colors here. Place your beds in such a way that your head should never point in the North direction");
                        break;
                    case "Pooja Room":
                        fruitInfoTextView.setText("Pooja Room is most energetic, auspicious and sacred place in the entire house. Never build pooja room under a staircase or some cupboard, or in front of main door. Also toilets should not be beside. Ideal direction for pooja room is east/west/southeast");
                        break;
                    case "Entire Plot":
                        fruitInfoTextView.setText("Always keep some water object like fountain or Urli in the North of the House. The ideal shape of the house should be perfect Rectangle/Square. Have some plants at your home. Contruct the main entrance frame with wood most preferably. Avoid black colors.");
                        break;


                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}