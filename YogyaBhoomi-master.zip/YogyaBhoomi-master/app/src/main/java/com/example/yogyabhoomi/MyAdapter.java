package com.example.yogyabhoomi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
   Context context;
   ArrayList<User1> list;

    public MyAdapter(Context context, ArrayList<User1> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        User1 user1=list.get(position);
        holder.name.setText(user1.getName());
        holder.mobile.setText(user1.getMobile());
        holder.email.setText(user1.getEmail());
        holder.riskfactor.setText(user1.getRiskfactor());
        holder.lifesuitability.setText(user1.getLifesuitability());
        holder.sbcresult.setText(user1.getSbcresult());
        holder.suburb.setText(user1.getSuburb());
        holder.moisture.setText(user1.getMoisturepercentage());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
TextView name,mobile,email,riskfactor,lifesuitability,sbcresult,moisture,suburb;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.tvname);
            mobile=itemView.findViewById(R.id.tvmobile);
            email=itemView.findViewById(R.id.tvemail);
            riskfactor=itemView.findViewById(R.id.tvriskfactor);
            lifesuitability=itemView.findViewById(R.id.tvlifesuitability);
            sbcresult=itemView.findViewById(R.id.tvsbcresult);
            moisture=itemView.findViewById(R.id.tvmoisture);
            suburb=itemView.findViewById(R.id.tvsuburb);
        }
    }
}
