package com.example.yogyabhoomi;

public class User1 {
    String name;
    String mobile;
    String email;
    String riskfactor;
    String lifesuitability;
    String sbcresult;
    String moisturepercentage;
    String suburb;

    public User1() {
    }

    public User1(String name, String mobile, String email, String riskfactor, String lifesuitability, String sbcresult, String moisturepercentage, String suburb) {
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.riskfactor = riskfactor;
        this.lifesuitability = lifesuitability;
        this.sbcresult = sbcresult;
        this.moisturepercentage = moisturepercentage;
        this.suburb = suburb;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRiskfactor() {
        return riskfactor;
    }

    public void setRiskfactor(String riskfactor) {
        this.riskfactor = riskfactor;
    }

    public String getLifesuitability() {
        return lifesuitability;
    }

    public void setLifesuitability(String lifesuitability) {
        this.lifesuitability = lifesuitability;
    }

    public String getSbcresult() {
        return sbcresult;
    }

    public void setSbcresult(String sbcresult) {
        this.sbcresult = sbcresult;
    }

    public String getMoisturepercentage() {
        return moisturepercentage;
    }

    public void setMoisturepercentage(String moisturepercentage) {
        this.moisturepercentage = moisturepercentage;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }
}
