package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LocationTest extends AppCompatActivity {
    Button b1, b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_test);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), choicetest3.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                Intent intent=new Intent(getApplicationContext(), SBCTest.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                startActivity(intent);
            }
        });
    }
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(),choicetest.class));
    }
}