package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class first_vastu extends AppCompatActivity {
    Button b1, b2;

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), Development.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_vastu);
        b1 = findViewById(R.id.btn);
        b2 = findViewById(R.id.btn1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String suburb_local=getIntent().getStringExtra("suburb");
                String sbcresult=getIntent().getStringExtra("sbcresult");
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                String moisturevalue=getIntent().getStringExtra("moisturevalue");
                String moisturepercentage=getIntent().getStringExtra("moisturepercentage");
                String future=getIntent().getStringExtra("future");
                Intent intent=new Intent(getApplicationContext(),MainActivity3.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                intent.putExtra("sbcresult",sbcresult);
                intent.putExtra("moisturevalue",moisturevalue);
                intent.putExtra("moisturepercentage",moisturepercentage);
                intent.putExtra("suburb",suburb_local);
                intent.putExtra("future",future);
                startActivity(intent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String suburb_local=getIntent().getStringExtra("suburb");
                String sbcresult=getIntent().getStringExtra("sbcresult");
                String riskfactor=getIntent().getStringExtra("riskfactor");
                String lifesutability=getIntent().getStringExtra("lifesutability");
                String moisturevalue=getIntent().getStringExtra("moisturevalue");
                String moisturepercentage=getIntent().getStringExtra("moisturepercentage");
                String future=getIntent().getStringExtra("future");
                Intent intent=new Intent(getApplicationContext(),main_vastu.class);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                intent.putExtra("sbcresult",sbcresult);
                intent.putExtra("moisturevalue",moisturevalue);
                intent.putExtra("moisturepercentage",moisturepercentage);
                intent.putExtra("suburb",suburb_local);
                intent.putExtra("future",future);
                startActivity(intent);
            }
        });
    }
}