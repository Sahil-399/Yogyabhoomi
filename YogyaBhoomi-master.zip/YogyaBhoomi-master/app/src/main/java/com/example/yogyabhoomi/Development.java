package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Development extends AppCompatActivity {

    private Object maharashtra_district;
    Button b1, b2;
    String selectedState,selectedSuburb;
    String selectedDistrict,selectedCity;

    int cityFlag=0,stateFlag=0,districtFlag=0,suburbFlag=0;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(),MoistureTest.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_development);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        Spinner statesSpinner = findViewById(R.id.states);
        Spinner districtsSpinner = findViewById(R.id.districts);
        Spinner citySpinner = findViewById(R.id.taluka);
        Spinner suburbSpinner=findViewById(R.id.suburb);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.states));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statesSpinner.setAdapter(adapter);
        String stateName;

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(stateFlag==1 && districtFlag==1 && cityFlag==1 && suburbFlag==1)
                {   String sbcresult=getIntent().getStringExtra("sbcresult");
                    String riskfactor=getIntent().getStringExtra("riskfactor");
                    String lifesutability=getIntent().getStringExtra("lifesutability");
                    String moisturevalue=getIntent().getStringExtra("moisturevalue");
                    String moisturepercentage=getIntent().getStringExtra("moisturepercentage");
                    Intent intent=new Intent(getApplicationContext(),development_Main.class);
                    intent.putExtra("riskfactor",riskfactor);
                    intent.putExtra("lifesutability",lifesutability);
                    intent.putExtra("sbcresult",sbcresult);
                    intent.putExtra("moisturevalue",moisturevalue);
                    intent.putExtra("moisturepercentage",moisturepercentage);
                    intent.putExtra("state",selectedState);
                    intent.putExtra("district",selectedDistrict);
                    intent.putExtra("city",selectedCity);
                    intent.putExtra("suburb",selectedSuburb);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(Development.this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        statesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                stateFlag=1;
                selectedState = parent.getItemAtPosition(position).toString();
                switch (selectedState.toLowerCase()) {
                    case "andhra pradesh":
                        break;
                    case "arunachal pradesh":
                        break;
                    case "assam":
                        break;
                    case "bihar":
                        break;
                    case "chhattisgarh":
                        break;
                    case "goa":
                        break;
                    case "gujarat":
                        break;
                    case "haryana":
                        break;
                    case "himachal pradesh":
                        break;
                    case "jammu and kashmir":
                        break;
                    case "jharkhand":
                        break;
                    case "karnataka":
                        break;
                    case "kerala":
                        break;
                    case "madhya pradesh":
                        break;
                    case "maharashtra":
                        getDistrictList("maharashtra_district");
                        break;
                    case "manipur":
                        break;
                    case "meghalaya":
                        break;
                    case "mizoram":
                        break;
                    case "nagaland":
                        break;
                    case "odisha":
                        break;
                    case "punjab":
                        break;
                    case "rajasthan":
                        break;
                    case "sikkim":
                        break;
                    case "tamil nadu":
                        break;
                    case "telangana":
                        break;
                    case "tripura":
                        break;
                    case "uttar pradesh":
                        break;
                    case "uttarakhand":
                        break;
                    case "west bengal":
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + selectedState.toLowerCase());
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {
                stateFlag=0;
            }

            private void getDistrictList(String maharashtra_district) {
                ArrayAdapter<String> districtAdapter = new ArrayAdapter<>(Development.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.maharashtra_districts));
                districtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                districtsSpinner.setAdapter(districtAdapter);
                districtsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        districtFlag=1;
                        selectedDistrict = districtsSpinner.getItemAtPosition(i).toString();
                        switch (selectedDistrict.toLowerCase()) {
                            case "mumbai":
                                break;
                            case "pune":
                                getCitiesList("pune");
                                break;
                            case "nagpur":
                                break;
                            case "aurangabad":
                                break;
                            case "nashik":
                                break;
                            case "thane":
                                break;
                            case "amravati":
                            default:

                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {
                        districtFlag=1;
                    }

                    private void getCitiesList(String district) {
                        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(Development.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.pune_cities));
                        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        citySpinner.setAdapter(cityAdapter);
                        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                cityFlag=1;
                                selectedCity = citySpinner.getItemAtPosition(i).toString();
                                switch (selectedCity.toLowerCase()) {
                                    case "talegaon dabhade":
                                        break;
                                    case "pune":
                                        break;
                                    case "pimpri-chinchwad":
                                        getSuburbList("pimpri chinchwad");
                                        break;
                                    case "lonavala":
                                        break;
                                    case "baramati":
                                        break;
                                    case "chakan":
                                        break;
                                    case "vadgaon":
                                        break;
                                    case "alandi":
                                        break;


                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {
                                cityFlag=0;
                            }

                            private void getSuburbList(String cityName){
                                ArrayAdapter<String> suburbAdapter = new ArrayAdapter<>(Development.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.pcmc_suburb));
                                suburbAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                suburbSpinner.setAdapter(suburbAdapter);
                                suburbSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                        suburbFlag=1;
                                        selectedSuburb=suburbSpinner.getItemAtPosition(i).toString();
                                        switch  (selectedSuburb.toLowerCase()){
                                            case "akurdi":
                                                Toast.makeText(Development.this, "Akurdi Sub-Urb Selected", Toast.LENGTH_SHORT).show();
                                                break;
                                            case "pune":
                                                break;
                                            case "pradhikaran":
                                                break;
                                            case "ravet":
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> adapterView) {
                                        suburbFlag=0;
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });


    }


}