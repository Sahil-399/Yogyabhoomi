package com.example.yogyabhoomi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    FirebaseAuth auth;
    FirebaseUser user;
    Button button;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        button = findViewById(R.id.btn);
        textView = findViewById(R.id.username);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), choicetest.class));
            }
        });
        if (user == null) {
            startActivity(new Intent(getApplicationContext(), LoginPage.class));
            finish();
        } else {
            textView.setText(user.getEmail());
        }

        /*-----------------------Hooks---------------------*/
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar1);



        /*---------------------Navigation Drawer Menu-------------------*/
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.OpenDrawer, R.string.CloseDrawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.home);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
        startActivity(new Intent(getApplicationContext(), MainActivity2.class));
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            /*0.1.HomePage*/
            case R.id.home:
                break;
            /*0.2.ProfilePage*/
            case R.id.profile:
                String name = getIntent().getStringExtra("name");
                String mobile = getIntent().getStringExtra("mobile");
                Intent intent = new Intent(getApplicationContext(), profile.class);
                intent.putExtra("name", name);
                intent.putExtra("mobile", mobile);
                startActivity(intent);
                break;
            /*1.ChoiceTest*/
            case R.id.choice:
                startActivity(new Intent(getApplicationContext(), choicetest.class));
                break;
            /*2.*/
            case R.id.location:
                startActivity(new Intent(getApplicationContext(), LocationTest.class));
                break;
            /*5*/
            case R.id.sbc:
                startActivity(new Intent(getApplicationContext(), SBCTest.class));
                break;
            /*6*/
            case R.id.moisture:
                startActivity(new Intent(getApplicationContext(), MoistureTest.class));
                break;
            /*7*/
            case R.id.future:
                startActivity(new Intent(getApplicationContext(), Development.class));
                break;
            /*8*/
            case R.id.vastu:
                startActivity(new Intent(getApplicationContext(), first_vastu.class));
                break;
            /*9.Logout*/
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), LoginPage.class));
                finish();
                break;

        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
