package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class choice_result extends AppCompatActivity {
    double progress = 0;
    int progress_meter = 0;
    double lifestyle=0;
    int lifestyle_meter=0;
    ProgressBar progressBar, progressBar1;
    TextView textView, textView1;
    Button b1, b2;
    int riskfactor = 0;
    int lifefactor=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_result);
        progressBar = findViewById(R.id.progress_bar);
        progressBar1 = findViewById(R.id.progress_bar1);
        textView = findViewById(R.id.progress_meter);
        textView1 = findViewById(R.id.progress_meter1);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        String ct1 = getIntent().getStringExtra("ct1");
        String ct2 = getIntent().getStringExtra("ct2");
        String ct3 = getIntent().getStringExtra("ct3");
        String ct4 = getIntent().getStringExtra("ct4");
        String ct5 = getIntent().getStringExtra("ct5");
        String ct6 = getIntent().getStringExtra("ct6");
        String ct7 = getIntent().getStringExtra("ct7");
        String ct8 = getIntent().getStringExtra("ct8");
        String ct9 = getIntent().getStringExtra("ct9");
        String ct10 = getIntent().getStringExtra("ct10");
        String ct11 = getIntent().getStringExtra("ct11");
        String ct12 = getIntent().getStringExtra("ct12");
        String ct13 = getIntent().getStringExtra("ct13");
        String ct14 = getIntent().getStringExtra("ct14");
        String ct15 = getIntent().getStringExtra("ct15");
        String ct16 = getIntent().getStringExtra("ct16");
        if (ct2.equals("No")) {
            riskfactor++;
        }
        if (ct4.equals("Yes")) {
            riskfactor++;
        }
        if (ct6.equals("Yes")) {
            riskfactor++;
        }
        if (ct7.equals("No")) {
            riskfactor++;
        }
        if (ct8.equals("Yes")) {
            riskfactor++;
            if (ct9.equals("Yes")) {
                riskfactor++;
            }
        }
        if (ct9.equals("Yes")) {
            if (ct10.equals("No")) {
                riskfactor++;
            }
        }
        //----------------------------Lifestyle suitability-------------------------------//
        if (ct9.equals("Yes")) {
            if (ct10.equals("Yes")) {
               lifefactor++;
            }
        }
        if (ct9.equals("No")) {
            if (ct10.equals("No")) {
                lifefactor++;
            }
        }
        if (ct11.equals("Yes")) {
            if (ct12.equals("Yes")) {
                lifefactor++;
            }
        }
        if (ct11.equals("No")) {
            if (ct12.equals("No")) {
                lifefactor++;
            }
        }

        if (ct13.equals("Yes")) {
            if (ct14.equals("Yes")) {
                lifefactor++;
            }
        }
        if (ct11.equals("No")) {
            if (ct12.equals("No")) {
                lifefactor++;
            }
        }
        if (ct15.equals("Yes")) {
            lifefactor++;
        }
        if (ct16.equals("Yes")) {
            lifefactor++;
        }

        progress = (((double) riskfactor / 7) * 100);
        lifestyle = (((double) lifefactor / 5) * 100);
        progress_meter = (int) Math.round(progress);
        lifestyle_meter = (int) Math.round(lifestyle);
        updateProgress();


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),choicetest.class));

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),LocationTest.class);
                String riskfactor=String.valueOf(progress_meter);
                String lifesutability=String.valueOf(lifestyle_meter);
                intent.putExtra("riskfactor",riskfactor);
                intent.putExtra("lifesutability",lifesutability);
                startActivity(intent);
            }
        });
    }

    private void updateProgress() {
        progressBar.setProgress(progress_meter);
        progressBar1.setProgress(lifestyle_meter);
        textView.setText(progress_meter + "%");
        textView1.setText(lifestyle_meter + "%");
    }


}