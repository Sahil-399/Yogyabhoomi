package com.example.yogyabhoomi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class choicetest extends AppCompatActivity {
    Button b1, b2;
    RadioGroup radioGroup1, radioGroup2, radioGroup3, radioGroup4, radioGroup5;
    RadioButton radioButton1, radioButton2, radioButton3, radioButton4, radioButton5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choicetest);
        b1 = findViewById(R.id.appCompatButton);
        b2 = findViewById(R.id.appCompatButton2);
        radioGroup1 = findViewById(R.id.radioGroup);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        radioGroup4 = findViewById(R.id.radioGroup4);
        radioGroup5 = findViewById(R.id.radioGroup5);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity2.class));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId1 = radioGroup1.getCheckedRadioButtonId();
                int radioId2 = radioGroup2.getCheckedRadioButtonId();
                int radioId3 = radioGroup3.getCheckedRadioButtonId();
                int radioId4 = radioGroup4.getCheckedRadioButtonId();
                int radioId5 = radioGroup5.getCheckedRadioButtonId();
                radioButton1 = findViewById(radioId1);
                radioButton2 = findViewById(radioId2);
                radioButton3 = findViewById(radioId3);
                radioButton4 = findViewById(radioId4);
                radioButton5 = findViewById(radioId5);
                String ct1 = radioButton1.getText().toString();
                String ct2 = radioButton2.getText().toString();
                String ct3 = radioButton3.getText().toString();
                String ct4 = radioButton4.getText().toString();
                String ct5 = radioButton5.getText().toString();
                if (!ct1.isEmpty() && !ct2.isEmpty() && !ct3.isEmpty() && !ct4.isEmpty() && !ct5.isEmpty()) {
                    Intent intent=new Intent(getApplicationContext(),choicetest2.class);
                    intent.putExtra("ct1",ct1);
                    intent.putExtra("ct2",ct2);
                    intent.putExtra("ct3",ct3);
                    intent.putExtra("ct4",ct4);
                    intent.putExtra("ct5",ct5);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(choicetest.this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), MainActivity2.class));
    }
}